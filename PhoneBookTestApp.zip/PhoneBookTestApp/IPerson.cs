﻿namespace PhoneBookTestApp
{

    public interface IPerson
    {
        string name { get; }

        string phoneNumber { get; }
        string address { get; }

        void Print();
    }
}
