﻿using NUnit.Framework;
using PhoneBookTestApp;
 

namespace PhoneBookTestAppTests
{
    // ReSharper disable InconsistentNaming

    [TestFixture]
    public class PhoneBookTest
    { 
        [Test]
        public void addPersonthrowException()
        { 
            IPhoneBook phonebook = new PhoneBook();
            Assert.Throws<System.Exception>(() => phonebook.AddPerson(null)); 
        }
        [Test]
        public void findPersonthrowException()
        {  
            IPhoneBook phonebook = new PhoneBook(); 
            Assert.Throws<System.Exception>(() => phonebook.FindPerson(null ,null)); 
        } 
     
    } 
    // ReSharper restore InconsistentNaming 
}