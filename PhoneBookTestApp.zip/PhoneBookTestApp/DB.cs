﻿using System;
using System.Data;
using System.Data.SQLite;

namespace PhoneBookTestApp
{
    public class DB : IDisposable
    {
        private SQLiteConnection _dbConnection;
        private SQLiteCommand _command;

        public SQLiteConnection dbConnection { get { return _dbConnection; } }
        public SQLiteCommand command { get { return _command; } }
        public DB(string Connectionstring)
        {
            Init(Connectionstring);
        }

        private void Init(string connectionString)
        {
            if (_dbConnection != null)
                _dbConnection.Close();

            _dbConnection = new SQLiteConnection(connectionString);
            _dbConnection.Open();

            _command = new SQLiteCommand();
            _command.Connection = _dbConnection;
            _command.CommandTimeout = 500000;

        }

        public void Dispose()
        {
            if (dbConnection != null)
            {
                if (_dbConnection.State == ConnectionState.Open)
                    _dbConnection.Close();

                _dbConnection.Dispose();
                _dbConnection = null;

                if (_command == null)
                    _command.Dispose();

                _command = null;

                GC.SuppressFinalize(this);
            }
        }
    }
}
