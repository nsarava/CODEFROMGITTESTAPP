﻿using System;

namespace PhoneBookTestApp
{
    public class DatabaseUtil
    {
        public DatabaseUtil()
        {

        }
        public void initializeDatabase()
        {
            //var dbConnection = new SQLiteConnection("Data Source= MyDatabase.sqlite;Version=3;");
            // dbConnection.Open();

            try
            {
                ExecuteCommand("create table IF NOT EXISTS  PHONEBOOK(NAME varchar(255), PHONENUMBER varchar(255), ADDRESS varchar(255))");

                InsertPerson(new Person("Chris Johnson", "(321) 231-7876", "452 Freeman Drive, Algonac, MI"));

                InsertPerson(new Person("Dave Williams", "(231) 502-1236", "285 Huron St, Port Austin, MI"));

                //SQLiteCommand command =
                //    new SQLiteCommand(
                //        "create table PHONEBOOK (NAME varchar(255), PHONENUMBER varchar(255), ADDRESS varchar(255))",
                //        dbConnection);
                //command.ExecuteNonQuery();  
                //command =
                //    new SQLiteCommand(
                //        "INSERT INTO PHONEBOOK (NAME, PHONENUMBER, ADDRESS) VALUES('Chris Johnson','(321) 231-7876', '452 Freeman Drive, Algonac, MI')",
                //        dbConnection);
                //command.ExecuteNonQuery(); 

                //command =
                //    new SQLiteCommand(
                //        "INSERT INTO PHONEBOOK (NAME, PHONENUMBER, ADDRESS) VALUES('Dave Williams','(231) 502-1236', '285 Huron St, Port Austin, MI')",
                //        dbConnection);
                //command.ExecuteNonQuery();

            }
            catch (Exception e)
            {
                Console.WriteLine($"Error : {e.Message.ToString()} { e.StackTrace.ToString() }");
                throw;
            }
            finally
            {

            }
        }

        public void InsertPerson(IPerson _person)
        {
            if (_person == null)
                throw new Exception("Person object is null");

            var insertcommandtext = "INSERT INTO PHONEBOOK(NAME, PHONENUMBER, ADDRESS) VALUES('" + _person.name + "', '" + _person.phoneNumber + "', '" + _person.address + "')";
            ExecuteCommand(insertcommandtext);
        }

        private void ExecuteCommand(string commandtext)
        {
            try
            {
                using (DB db = new DB("Data Source= MyDatabase.sqlite;Version=3;"))
                {
                    db.command.CommandText = commandtext;
                    db.command.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error : {e.Message.ToString()} { e.StackTrace.ToString() }");
                throw;
            }
            finally
            {

            }
        }

        //public static SQLiteConnection GetConnection()
        //{
        //    var dbConnection = new SQLiteConnection("Data Source= MyDatabase.sqlite;Version=3;");
        //    dbConnection.Open();

        //    return dbConnection;
        //}

        public void CleanUp()
        {
            //   var dbConnection = new SQLiteConnection("Data Source= MyDatabase.sqlite;Version=3;");
            //  dbConnection.Open();

            try
            {
                ExecuteCommand("drop table PHONEBOOK");
                //SQLiteCommand command =new SQLiteCommand("drop table PHONEBOOK",dbConnection);
                //command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error : {e.Message.ToString()} { e.StackTrace.ToString() }");
                throw;
            }
            finally
            {

            }
        }
    }


}