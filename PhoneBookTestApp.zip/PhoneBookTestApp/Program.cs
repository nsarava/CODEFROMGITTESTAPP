﻿using System;

namespace PhoneBookTestApp
{
    class Program
    { 
        static void Main(string[] args)
        {
            IPhoneBook phonebook = new PhoneBook();
            var dbutil = new DatabaseUtil();
            try
            { 
                dbutil.initializeDatabase();

                var person1 = new Person("John Smith", "(248) 123-4567", "1234 Sand Hill Dr, Royal Oak, MI");

                dbutil.InsertPerson(person1);
                phonebook.AddPerson(person1);

                var person2 = new Person("Cynthia Smith", "(824) 128-8758", "875 Main St, Ann Arbor, MI");

                dbutil.InsertPerson(person2);
                phonebook.AddPerson(person2);

                /* TODO: create person objects and put them in the PhoneBook and database
                * John Smith, (248) 123-4567, 1234 Sand Hill Dr, Royal Oak, MI
                * Cynthia Smith, (824) 128-8758, 875 Main St, Ann Arbor, MI
                */

                phonebook.PrintAll();
                // TODO: print the phone book out to System.out
                var FindPerson = phonebook.FindPerson("Cynthia", "Smith");
                phonebook.PrintPerson(FindPerson);

                // TODO: find Cynthia Smith and print out just her entry
                // TODO: insert the new person objects into the database
                dbutil.InsertPerson(new Person("Nithiy Sarava", "248 971 4349", "Walden Drive, Bloomfield Hills, MI"));

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message.ToString());
                Console.ReadLine();
            } 
            finally
            {
                dbutil.CleanUp();
                phonebook = null;
                dbutil = null;
                Console.ReadLine();
            }
        }
    }
}
