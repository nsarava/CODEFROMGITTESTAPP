﻿using System;

namespace PhoneBookTestApp
{
    public class Person : IPerson
    {
        public Person(string name_, string phoneNumber_, string address_)
        {
            name = name_;
            phoneNumber = phoneNumber_;
            address = address_;
        }

        public void Print()
        {
            Console.WriteLine($"{this.name} {this.address} {this.phoneNumber}");
        } 

        public string name { get; }


        public string address { get;}


        public string phoneNumber { get; }
    }

}