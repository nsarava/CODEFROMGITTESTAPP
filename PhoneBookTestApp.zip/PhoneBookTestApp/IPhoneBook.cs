﻿namespace PhoneBookTestApp
{
    public interface IPhoneBook
    {
        IPerson FindPerson(string firstName, string lastName);
        void AddPerson(IPerson newPerson);

        void PrintAll();

        void PrintPerson(IPerson person);
    }
}