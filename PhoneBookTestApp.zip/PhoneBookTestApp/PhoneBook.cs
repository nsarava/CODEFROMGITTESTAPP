﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PhoneBookTestApp
{
    public class PhoneBook : IPhoneBook
    {
        List<IPerson> phonecontact = new List<IPerson>();
        public PhoneBook()
        {

        }
        public void AddPerson(IPerson newPerson)
        {
            if (newPerson == null)
                throw new Exception("Person Object is null");
            phonecontact.Add(newPerson);
        } 
        public IPerson FindPerson(string firstName, string lastName)
        {
            if ((firstName == null && lastName == null) || (firstName == "" && lastName == ""))
                throw new Exception("First Name and Last Name both are missing");
            var name = $"{firstName} {lastName}";
            var person =  phonecontact.Where(c => c.name == $"{name}").FirstOrDefault();
            if (person == null)
                throw new Exception($"Can not find {name}");
            return person;
        } 
        public void PrintAll()
        {
            phonecontact.ForEach(c => c.Print());
        } 
        public void PrintPerson(IPerson person)
        {
            person.Print();
        }

        public List<IPerson> Phonecontact { get { return phonecontact; } }
    }
}